const express = require('express');
const { conectarBancoMV } = require('./config/db');
const tutorRoutes = require('./routes/tutorRoutes');
const animalRoutes = require('./routes/animalRoutes');
const consultaRoutes = require('./routes/consultaRoutes');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Rotas modulares
app.use('/tutores', tutorRoutes);
app.use('/animais', animalRoutes);
app.use('/consultas', consultaRoutes);

const iniciarServidorMV = async () => {
  await conectarBancoMV();
  app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
  });
};

iniciarServidorMV();
