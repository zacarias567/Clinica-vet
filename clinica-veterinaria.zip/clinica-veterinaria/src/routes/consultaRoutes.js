const express = require('express');
const router = express.Router();
const consultaController = require('../controllers/consultaController');

router.get('/', consultaController.listarConsultasMV);
router.get('/:id', consultaController.obterConsultaPorIdMV);
router.post('/', consultaController.criarConsultaMV);
router.put('/:id', consultaController.atualizarConsultaMV);
router.delete('/:id', consultaController.removerConsultaMV);

module.exports = router;
