const express = require('express');
const router = express.Router();
const animalController = require('../controllers/animalController');

router.get('/', animalController.listarAnimaisMV);
router.get('/:id', animalController.obterAnimalPorIdMV);
router.post('/', animalController.criarAnimalMV);
router.put('/:id', animalController.atualizarAnimalMV);
router.delete('/:id', animalController.removerAnimalMV);
router.get('/:id/consultas', animalController.listarConsultasPorAnimalMV);

module.exports = router;
