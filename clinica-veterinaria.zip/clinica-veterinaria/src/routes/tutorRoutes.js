const express = require('express');
const router = express.Router();
const tutorController = require('../controllers/tutorController');

router.get('/', tutorController.listarTutoresMV);
router.get('/:id', tutorController.obterTutorPorIdMV);
router.post('/', tutorController.criarTutorMV);
router.put('/:id', tutorController.atualizarTutorMV);
router.delete('/:id', tutorController.removerTutorMV);

module.exports = router;
