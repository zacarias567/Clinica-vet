const { DataTypes } = require('sequelize');
const { sequelizeMV } = require('../config/db');

const TutorMV = sequelizeMV.define('Tutor', {
  nome: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  telefone: DataTypes.STRING(20),
  email: DataTypes.STRING(100)
}, {
  tableName: 'tutores'
});

const AnimalMV = sequelizeMV.define('Animal', {
  nome: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  especie: DataTypes.STRING(50),
  raca: DataTypes.STRING(50),
  data_nascimento: DataTypes.DATEONLY,
  tutor_id: {
    type: DataTypes.INTEGER,
    references: {
      model: TutorMV,
      key: 'id'
    }
  }
}, {
  tableName: 'animais'
});

const ConsultaMV = sequelizeMV.define('Consulta', {
  animal_id: {
    type: DataTypes.INTEGER,
    references: {
      model: AnimalMV,
      key: 'id'
    }
  },
  data_consulta: {
    type: DataTypes.DATE,
    allowNull: false
  },
  motivo: DataTypes.TEXT,
  diagnostico: DataTypes.TEXT,
  veterinario: DataTypes.STRING(100)
}, {
  tableName: 'consultas'
});

// Relacionamentos
TutorMV.hasMany(AnimalMV, { foreignKey: 'tutor_id' });
AnimalMV.belongsTo(TutorMV, { foreignKey: 'tutor_id' });

AnimalMV.hasMany(ConsultaMV, { foreignKey: 'animal_id' });
ConsultaMV.belongsTo(AnimalMV, { foreignKey: 'animal_id' });

module.exports = { TutorMV, AnimalMV, ConsultaMV };
